

// bring connect into our file
var connect = require('connect');


// load in the url module to parse url parameters
var url = require('url');

// bring in the filesystem module
var fs = require('fs');

// instantiate our app from connect
var app = connect();

// make our calculus function
function calculus(req, res){
    // grab the three parameters from the url
    // http://localhost:3000/lab3.js?method=multiply&x=16&y=4
    var input = url.parse(req.url, true).query;
    var Xvalue = parseFloat(input.x);
    var Yvalue = parseFloat(input.y);
    var method = input.method ;

    switch(method){
        case "add":
            endFunction(res,Xvalue,Yvalue,"+",(Xvalue+Yvalue));
            break;
        case "subtract":
            endFunction(res,Xvalue,Yvalue,"-",(Xvalue-Yvalue));
            break;
        case "multiply":
            endFunction(res,Xvalue,Yvalue,"*",(Xvalue*Yvalue));
            break;
        case "divide":
            endFunction(res,Xvalue,Yvalue,"/",(Xvalue/Yvalue));
            break;
        default:
            res.end("Error Incorrect value");

    }

}

function endFunction(alt,val1,val2,val3,resl){
    alt.end("calculation:- "+val1 +" "+val3+ " "+ val2+" = "+ resl );

}

app.use('/lab3.js',calculus)




// actually start the server, on
// port 3000
app.listen(3000)

// spit out to the console telling us
// that the server is running
console.log('Connect running on port 3000')

